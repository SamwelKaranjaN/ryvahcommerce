<?php
// Simple error logging for PayPal debugging
require_once '../includes/bootstrap.php';

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set proper content type
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Get POST data
$input = file_get_contents('php://input');

// Log the raw input for debugging
error_log("log_error.php - Raw input received: " . $input);
error_log("log_error.php - Content length: " . strlen($input));
error_log("log_error.php - Content type: " . ($_SERVER['CONTENT_TYPE'] ?? 'Not set'));
error_log("log_error.php - Request method: " . $_SERVER['REQUEST_METHOD']);

// Handle empty input
if (empty($input)) {
    error_log("log_error.php - Empty input received");
    http_response_code(400);
    echo json_encode(['error' => 'No data received', 'debug' => 'Empty input']);
    exit;
}

// Try to decode JSON
$data = json_decode($input, true);
$json_error = json_last_error();

if ($json_error !== JSON_ERROR_NONE) {
    $json_error_msg = json_last_error_msg();
    error_log("log_error.php - JSON decode error: " . $json_error_msg);
    error_log("log_error.php - JSON error code: " . $json_error);

    // Try to handle form-encoded data as fallback
    if ($_SERVER['CONTENT_TYPE'] === 'application/x-www-form-urlencoded') {
        parse_str($input, $data);
        if (!empty($data)) {
            error_log("log_error.php - Successfully parsed as form data");
        } else {
            http_response_code(400);
            echo json_encode([
                'error' => 'Invalid data format',
                'json_error' => $json_error_msg,
                'debug' => 'Neither JSON nor form data',
                'raw_input' => substr($input, 0, 200) . (strlen($input) > 200 ? '...' : '')
            ]);
            exit;
        }
    } else {
        http_response_code(400);
        echo json_encode([
            'error' => 'Invalid JSON data',
            'json_error' => $json_error_msg,
            'debug' => 'Failed to parse JSON',
            'raw_input' => substr($input, 0, 200) . (strlen($input) > 200 ? '...' : '')
        ]);
        exit;
    }
}

// Log the error
$logEntry = [
    'timestamp' => date('Y-m-d H:i:s'),
    'user_id' => $_SESSION['user_id'],
    'error' => $data['error'] ?? 'Unknown error',
    'context' => $data['context'] ?? 'Unknown context',
    'user_agent' => $data['userAgent'] ?? $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
    'request_time' => $data['timestamp'] ?? date('c')
];

// Write to error log
error_log("PayPal Error Log: " . json_encode($logEntry));

// Optionally store in database for analysis
try {
    $stmt = $conn->prepare("INSERT INTO payment_logs (order_id, status, message, metadata, created_at) VALUES (?, 'failed', ?, ?, NOW())");
    $order_id = 0; // No specific order for general errors
    $message = $data['context'] . ': ' . $data['error'];
    $metadata = json_encode($logEntry);

    $stmt->bind_param("iss", $order_id, $message, $metadata);
    $stmt->execute();
} catch (Exception $e) {
    // If database logging fails, just log to file
    error_log("Failed to log PayPal error to database: " . $e->getMessage());
}

echo json_encode(['status' => 'logged', 'message' => 'Error logged successfully']);