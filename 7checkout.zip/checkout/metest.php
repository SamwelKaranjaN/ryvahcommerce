<!DOCTYPE html>
<html>

<head>
    <title>PayPal Sandbox Test</title>
    <script
        src="https://www.paypal.com/sdk/js?client-id=ARb4izn3jwTWc2j2x6UDmompOiO2Uq3HQKodHTR3Y6UKUN61daJD09G8JVrx6UWz11-CL2fcty8UJ2CJ&currency=USD&intent=capture">
    </script>
</head>

<body>
    <h2>PayPal Sandbox Checkout</h2>
    <div id="paypal-button-container"></div>

    <script>
    paypal.Buttons({
        createOrder: function(data, actions) {
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: '10.00' // test amount
                    }
                }]
            });
        },
        onApprove: function(data, actions) {
            return actions.order.capture().then(function(details) {
                alert('Transaction completed by ' + details.payer.name.given_name);
                console.log(details);
            });
        },
        onError: function(err) {
            console.error('PayPal error:', err);
        }
    }).render('#paypal-button-container');
    </script>
</body>

</html>