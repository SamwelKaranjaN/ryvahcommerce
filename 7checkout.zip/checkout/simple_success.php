<?php
require_once '../includes/bootstrap.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../pages/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['order']) ? (int)$_GET['order'] : 0;

if (!$order_id) {
    header('Location: ../pages/index.php');
    exit;
}

// Get order details
$stmt = $conn->prepare("
    SELECT o.*, u.full_name, u.email 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    WHERE o.id = ? AND o.user_id = ? AND o.payment_status = 'completed'
");
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header('Location: ../pages/index.php');
    exit;
}

// Get order items
$stmt = $conn->prepare("
    SELECT oi.*, p.name, p.author, p.thumbs, p.type
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = ?
");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get download links
$stmt = $conn->prepare("
    SELECT ed.*, p.name, p.type 
    FROM ebook_downloads ed 
    JOIN products p ON ed.product_id = p.id 
    WHERE ed.order_id = ? AND ed.user_id = ?
");
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$downloads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include '../includes/layouts/header.php';
?>

<div class="container py-5">
    <!-- Success Header -->
    <div class="text-center mb-5">
        <div class="success-icon mb-4">
            <i class="fas fa-check-circle fa-5x text-success"></i>
        </div>
        <h1 class="text-success mb-3">Order Confirmed!</h1>
        <p class="lead">Thank you for your purchase. Your order has been successfully processed.</p>
        <div class="alert alert-info d-inline-block">
            <strong>Order #<?php echo htmlspecialchars($order['invoice_number']); ?></strong>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Order Summary -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-receipt me-2"></i>Order Summary</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Order Date:</strong><br>
                            <span class="text-muted"><?php echo date('M j, Y g:i A', strtotime($order['order_date'])); ?></span>
                        </div>
                        <div class="col-md-6">
                            <strong>Payment Method:</strong><br>
                            <span class="text-muted">
                                <i class="fab fa-paypal text-primary"></i> PayPal
                            </span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Customer:</strong><br>
                            <span class="text-muted"><?php echo htmlspecialchars($order['full_name']); ?></span><br>
                            <span class="text-muted"><?php echo htmlspecialchars($order['email']); ?></span>
                        </div>
                        <div class="col-md-6">
                            <strong>Total Paid:</strong><br>
                            <span class="h5 text-success">$<?php echo number_format($order['total_amount'], 2); ?></span>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>PayPal Order ID:</span>
                        <code><?php echo htmlspecialchars($order['paypal_order_id']); ?></code>
                    </div>
                </div>
            </div>

            <!-- Order Items -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-box me-2"></i>Items Purchased</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($order_items as $item): ?>
                        <div class="d-flex align-items-center mb-3 pb-3 <?php echo $item !== end($order_items) ? 'border-bottom' : ''; ?>">
                            <img src="../admin/<?php echo htmlspecialchars($item['thumbs']); ?>"
                                class="me-3" style="width: 60px; height: 60px; object-fit: cover;">
                            <div class="flex-grow-1">
                                <h6 class="mb-1"><?php echo htmlspecialchars($item['name']); ?></h6>
                                <?php if ($item['author']): ?>
                                    <p class="text-muted mb-1 small">By <?php echo htmlspecialchars($item['author']); ?></p>
                                <?php endif; ?>
                                <span class="badge bg-secondary"><?php echo ucfirst($item['type']); ?></span>
                                <span class="text-muted ms-2">Qty: <?php echo $item['quantity']; ?></span>
                            </div>
                            <div class="text-end">
                                <strong>$<?php echo number_format($item['subtotal'], 2); ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Digital Downloads -->
            <?php if (!empty($downloads)): ?>
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-download me-2"></i>Digital Downloads</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Your digital products are ready for download. Downloads expire in 30 days with a limit of 5 downloads per item.
                        </div>

                        <?php foreach ($downloads as $download): ?>
                            <div class="download-item p-3 border rounded mb-3 bg-light">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1 text-primary"><?php echo htmlspecialchars($download['name']); ?></h6>
                                        <small class="text-muted">
                                            <i class="fas fa-download me-1"></i>
                                            Downloads: <?php echo $download['download_count']; ?>/<?php echo $download['max_downloads']; ?>
                                            <span class="ms-3">
                                                <i class="fas fa-clock me-1"></i>
                                                Expires: <?php echo date('M j, Y', strtotime($download['expires_at'])); ?>
                                            </span>
                                        </small>
                                    </div>
                                    <div>
                                        <?php if ($download['download_count'] < $download['max_downloads'] && strtotime($download['expires_at']) > time()): ?>
                                            <a href="../includes/download/download.php?token=<?php echo $download['download_token']; ?>"
                                                class="btn btn-success btn-sm">
                                                <i class="fas fa-download me-1"></i>Download Now
                                            </a>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Download Expired</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Action Buttons -->
            <div class="text-center">
                <a href="../pages/index" class="btn btn-primary btn-lg me-3">
                    <i class="fas fa-shopping-bag me-2"></i>Continue Shopping
                </a>
                <a href="../pages/orders" class="btn btn-outline-primary btn-lg">
                    <i class="fas fa-list me-2"></i>View All Orders
                </a>
            </div>
        </div>
    </div>
</div>

<style>
    .success-icon {
        animation: bounceIn 0.6s ease-out;
    }

    @keyframes bounceIn {
        0% {
            transform: scale(0.3);
            opacity: 0;
        }

        50% {
            transform: scale(1.05);
        }

        70% {
            transform: scale(0.9);
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    .download-item {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .download-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .card {
        border: 1px solid #dee2e6;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
</style>

<?php include '../includes/layouts/footer.php'; ?>