<?php

/**
 * PayPal SSL Bypass Test
 * 
 * This script tests PayPal connection with SSL verification disabled
 * to confirm if SSL certificates are the issue.
 */

echo "<h1>PayPal SSL Bypass Test</h1>";

// Your credentials
$client_id = 'ARb4izn3jwTWc2j2x6UDmompOiO2Uq3HQKodHTR3Y6UKUN61daJD09G8JVrx6UWz11-CL2fcty8UJ2CJ';
$client_secret = 'EDUXnHsBZ0L7gUXjdpI9l7oFnCTIftl0UORyDtsXIZqBb7reoiNhGlEI4U2Qv_lKsI_oaK1Z3eVhzOyW';

echo "<h2>Test 1: Original PayPal URL with SSL Bypass</h2>";

// Test with SSL verification disabled
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.sandbox.paypal.com/v1/oauth2/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Accept: application/json',
    'Accept-Language: en_US',
    'Authorization: Basic ' . base64_encode($client_id . ':' . $client_secret)
]);
// Disable SSL verification for WAMP
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "<p><strong>HTTP Code:</strong> " . $http_code . "</p>";

if ($error) {
    echo "<p style='color: red;'><strong>❌ Still Failed:</strong> " . htmlspecialchars($error) . "</p>";
} else {
    echo "<p style='color: green;'><strong>✅ Connection Successful!</strong></p>";

    $response_data = json_decode($response, true);
    if ($response_data) {
        echo "<p><strong>Response:</strong></p>";
        echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px;'>";
        echo htmlspecialchars(json_encode($response_data, JSON_PRETTY_PRINT));
        echo "</pre>";

        if (isset($response_data['access_token'])) {
            echo "<p style='color: green; font-weight: bold;'>🎉 SUCCESS: PayPal API working with SSL bypass!</p>";
            echo "<p style='background: #d4edda; padding: 10px; border-radius: 5px;'>";
            echo "<strong>Solution Found:</strong> SSL certificates are the issue. We can fix this in your PayPal integration.";
            echo "</p>";
        } elseif (isset($response_data['error'])) {
            echo "<p style='color: red; font-weight: bold;'>❌ Credentials Issue: " . htmlspecialchars($response_data['error_description'] ?? $response_data['error']) . "</p>";
        }
    }
}

echo "<h2>Test 2: Alternative URL with SSL Bypass</h2>";

// Test alternative URL with SSL bypass
$alt_ch = curl_init();
curl_setopt($alt_ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/oauth2/token');
curl_setopt($alt_ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($alt_ch, CURLOPT_TIMEOUT, 30);
curl_setopt($alt_ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($alt_ch, CURLOPT_POST, true);
curl_setopt($alt_ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
curl_setopt($alt_ch, CURLOPT_HTTPHEADER, [
    'Accept: application/json',
    'Accept-Language: en_US',
    'Authorization: Basic ' . base64_encode($client_id . ':' . $client_secret)
]);
// Disable SSL verification
curl_setopt($alt_ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($alt_ch, CURLOPT_SSL_VERIFYHOST, false);

$alt_response = curl_exec($alt_ch);
$alt_http_code = curl_getinfo($alt_ch, CURLINFO_HTTP_CODE);
$alt_error = curl_error($alt_ch);
curl_close($alt_ch);

echo "<p><strong>Alternative URL HTTP Code:</strong> " . $alt_http_code . "</p>";

if ($alt_error) {
    echo "<p style='color: red;'><strong>❌ Alternative URL Still Failed:</strong> " . htmlspecialchars($alt_error) . "</p>";
} else {
    echo "<p style='color: green;'><strong>✅ Alternative URL Working!</strong></p>";

    $alt_response_data = json_decode($alt_response, true);
    if ($alt_response_data && isset($alt_response_data['access_token'])) {
        echo "<p style='color: green; font-weight: bold;'>🎉 SUCCESS with alternative URL and SSL bypass!</p>";
    }
}

echo "<h2>Next Steps</h2>";
echo "<div style='background: #d1ecf1; padding: 15px; border-left: 4px solid #17a2b8; margin: 20px 0;'>";
echo "<h3>If either test succeeded:</h3>";
echo "<p>I can update your PayPal integration to use SSL bypass for WAMP development.</p>";

echo "<h3>Permanent Fix Options:</h3>";
echo "<ol>";
echo "<li><strong>Quick Fix:</strong> Use SSL bypass in development (I can implement this)</li>";
echo "<li><strong>Proper Fix:</strong> Update your WAMP SSL certificates:</li>";
echo "<ul>";
echo "<li>Download latest <code>cacert.pem</code> from <a href='https://curl.se/ca/cacert.pem' target='_blank'>curl.se</a></li>";
echo "<li>Place it in your PHP directory</li>";
echo "<li>Update <code>php.ini</code>: <code>curl.cainfo = \"path/to/cacert.pem\"</code></li>";
echo "<li>Restart WAMP</li>";
echo "</ul>";
echo "</ol>";
echo "</div>";