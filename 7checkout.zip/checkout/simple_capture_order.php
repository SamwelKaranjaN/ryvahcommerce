<?php
// Prevent cart.php POST handler from interfering
define('PAYPAL_ORDER_PROCESSING', true);

ob_start();
header('Content-Type: application/json');

require_once '../includes/bootstrap.php';
require_once '../includes/cart.php';
require_once '../includes/paypal_config.php';
require_once '../vendor/autoload.php';

// Start output buffering for clean JSON response
ob_start();

try {
    // Ensure session is started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Security: Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('User not authenticated');
    }

    // Validate PayPal configuration
    if (!validatePayPalConfig()) {
        throw new Exception('PayPal configuration is incomplete');
    }

    $credentials = getPayPalCredentials();

    // Get and validate request data
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!$data || !isset($data['orderID'])) {
        throw new Exception('No order ID provided');
    }

    $orderID = $data['orderID'];
    error_log("PayPal Capture Order - Environment: " . PAYPAL_ENVIRONMENT);
    error_log("PayPal Capture Order - Capturing order: " . $orderID);

    // Initialize PayPal client using config
    if (PAYPAL_ENVIRONMENT === 'sandbox') {
        $environment = new \PayPalCheckoutSdk\Core\SandboxEnvironment($credentials['client_id'], $credentials['client_secret']);
    } else {
        $environment = new \PayPalCheckoutSdk\Core\ProductionEnvironment($credentials['client_id'], $credentials['client_secret']);
    }
    $client = new \PayPalCheckoutSdk\Core\PayPalHttpClient($environment);

    error_log("PayPal Capture Order - PayPal " . PAYPAL_ENVIRONMENT . " client initialized");

    // Create capture request
    $request = new \PayPalCheckoutSdk\Orders\OrdersCaptureRequest($orderID);
    $request->prefer('return=representation');

    // Execute PayPal capture
    $response = $client->execute($request);

    error_log("PayPal Capture Order - PayPal capture response: " . json_encode($response->result));

    if ($response->result->status !== 'COMPLETED') {
        throw new Exception('Payment capture failed. Status: ' . $response->result->status);
    }

    // Update order status in database
    $stmt = $conn->prepare("SELECT id FROM orders WHERE paypal_order_id = ?");
    $stmt->bind_param("s", $orderID);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    if (!$order) {
        throw new Exception('Order not found in database');
    }

    // Update payment status
    $stmt = $conn->prepare("UPDATE orders SET payment_status = 'completed', updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $order['id']);

    if (!$stmt->execute()) {
        throw new Exception('Failed to update order status');
    }

    error_log("PayPal Capture Order - Payment completed successfully for order: " . $order['id']);

    // Clear cart after successful payment
    if (isset($_SESSION['cart'])) {
        unset($_SESSION['cart']);
    }

    // Return success response
    ob_clean();
    echo json_encode([
        'success' => true,
        'order_id' => $order['id'],
        'paypal_order_id' => $orderID,
        'status' => 'completed',
        'message' => 'Payment completed successfully',
        'environment' => PAYPAL_ENVIRONMENT
    ]);
} catch (Exception $e) {
    error_log("PayPal Capture Order - Error: " . $e->getMessage());
    error_log("PayPal Capture Order - Stack trace: " . $e->getTraceAsString());

    ob_clean();
    http_response_code(500);
    echo json_encode([
        'error' => 'Payment capture failed',
        'message' => $e->getMessage(),
        'environment' => PAYPAL_ENVIRONMENT ?? 'unknown'
    ]);
}

// Ensure clean output
ob_end_flush();
