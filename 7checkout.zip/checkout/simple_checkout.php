<?php
require_once '../includes/bootstrap.php';
require_once '../includes/cart.php';

// Simple configuration
define('SHOW_TESTING_NOTICES', true);

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Security: Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../pages/login?redirect=checkout/simple_checkout');
    exit;
}

// Get cart data
$cart_data = getCartItems();
$cart_items = $cart_data['items'];
$cart_total = $cart_data['total'];

// Simple tax calculation (10% flat rate for demo)
$tax_rate = 0.10;
$tax_amount = $cart_total * $tax_rate;
$grand_total = $cart_total + $tax_amount;

// Get user info
$stmt = $conn->prepare("SELECT full_name, email, phone FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user_info = $stmt->get_result()->fetch_assoc();

// Get user's default address (simplified)
$stmt = $conn->prepare("SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC LIMIT 1");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$default_address = $stmt->get_result()->fetch_assoc();

include '../includes/layouts/header.php';
?>

<div class="container py-4">
    <h1 class="mb-4">Simple Checkout</h1>

    <?php if (SHOW_TESTING_NOTICES): ?>
        <!-- Testing Mode Notice -->
        <div class="alert alert-info mb-4">
            <i class="fas fa-info-circle me-2"></i>
            <strong>Testing Mode Active:</strong> This checkout is currently running in testing mode due to PayPal API
            connectivity issues. Orders will be processed normally, but PayPal API calls are simulated.
        </div>
    <?php endif; ?>

    <?php if (empty($cart_items)): ?>
        <!-- Empty Cart -->
        <div class="text-center py-5">
            <i class="fas fa-shopping-cart fa-5x text-muted mb-4"></i>
            <h3>Your cart is empty</h3>
            <a href="../pages/index" class="btn btn-primary mt-3">Continue Shopping</a>
        </div>
    <?php else: ?>

        <div class="row">
            <!-- Order Summary -->
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-user me-2"></i>Customer Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>Name:</strong> <?php echo htmlspecialchars($user_info['full_name']); ?>
                            </div>
                            <div class="col-md-6">
                                <strong>Email:</strong> <?php echo htmlspecialchars($user_info['email']); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-box me-2"></i>Order Items</h5>
                    </div>
                    <div class="card-body">
                        <?php foreach ($cart_items as $item): ?>
                            <div class="d-flex align-items-center mb-3">
                                <img src="../admin/<?php echo htmlspecialchars($item['thumbs']); ?>" class="me-3"
                                    style="width: 60px; height: 60px; object-fit: cover;">
                                <div class="flex-grow-1">
                                    <h6><?php echo htmlspecialchars($item['name']); ?></h6>
                                    <small class="text-muted">Qty: <?php echo $item['quantity']; ?></small>
                                </div>
                                <strong>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></strong>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <?php if ($default_address): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5><i class="fas fa-map-marker-alt me-2"></i>Shipping Address</h5>
                        </div>
                        <div class="card-body">
                            <address>
                                <strong><?php echo htmlspecialchars($default_address['label']); ?></strong><br>
                                <?php echo htmlspecialchars($default_address['street']); ?><br>
                                <?php echo htmlspecialchars($default_address['city'] . ', ' . $default_address['state'] . ' ' . $default_address['postal_code']); ?>
                            </address>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Payment Section -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-credit-card me-2"></i>Payment</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <span>Subtotal:</span>
                                <span>$<?php echo number_format($cart_total, 2); ?></span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>Tax (10%):</span>
                                <span>$<?php echo number_format($tax_amount, 2); ?></span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <strong>Total:</strong>
                                <strong class="text-primary">$<?php echo number_format($grand_total, 2); ?></strong>
                            </div>
                        </div>

                        <?php if ($default_address): ?>
                            <!-- PayPal Button Container -->
                            <div id="paypal-button-container"></div>

                            <!-- Debug Info (remove in production) -->
                            <div id="debug-info" class="mt-3" style="display: none;">
                                <small class="text-muted">Debug info will appear here...</small>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <small>Please add a shipping address first.</small>
                                <br>
                                <a href="../pages/addresses" class="btn btn-sm btn-primary mt-2">Add Address</a>
                            </div>
                        <?php endif; ?>

                        <div class="text-center mt-3">
                            <small class="text-muted">
                                <i class="fas fa-lock me-1"></i>Secure Payment with PayPal
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- PayPal SDK - SANDBOX MODE FOR TESTING -->
<script
    src="https://www.paypal.com/sdk/js?client-id=ARb4izn3jwTWc2j2x6UDmompOiO2Uq3HQKodHTR3Y6UKUN61daJD09G8JVrx6UWz11-CL2fcty8UJ2CJ&currency=USD&intent=capture&debug=true">
</script>

<!-- TODO: For production, change to:
<script src="https://www.paypal.com/sdk/js?client-id=YOUR_PRODUCTION_CLIENT_ID&currency=USD&intent=capture"></script>
-->

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Debug function
        function debugLog(message, data = null) {
            console.log('🔧 [DEBUG]', message, data);
            const debugDiv = document.getElementById('debug-info');
            if (debugDiv) {
                debugDiv.style.display = 'block';
                debugDiv.innerHTML += '<br><small>' + message + (data ? ': ' + JSON.stringify(data) : '') +
                    '</small>';
            }
        }

        // Only initialize PayPal if we have an address
        <?php if ($default_address): ?>

            debugLog('Initializing PayPal with total', <?php echo $grand_total; ?>);
            debugLog('Address ID', <?php echo $default_address['id']; ?>);

            paypal.Buttons({
                    style: {
                        layout: 'vertical',
                        color: 'blue',
                        shape: 'rect',
                        label: 'paypal'
                    },

                    createOrder: function(data, actions) {
                        debugLog('Creating PayPal order...');

                        const orderData = {
                            total: <?php echo $grand_total; ?>,
                            address_id: <?php echo $default_address['id']; ?>
                        };

                        debugLog('Sending order data', orderData);

                        return fetch('simple_create_order.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify(orderData)
                            })
                            .then(response => {
                                debugLog('Create order response status', response.status);

                                if (!response.ok) {
                                    throw new Error(`HTTP error! status: ${response.status}`);
                                }

                                return response.text();
                            })
                            .then(text => {
                                debugLog('Raw response text', text);

                                try {
                                    const order = JSON.parse(text);
                                    debugLog('Parsed JSON response', order);

                                    if (order.error) {
                                        throw new Error(order.error + (order.message ? ': ' + order
                                            .message : ''));
                                    }

                                    if (!order.id) {
                                        throw new Error('No order ID returned from server. Response: ' +
                                            JSON.stringify(order));
                                    }

                                    debugLog('Order ID created successfully', order.id);
                                    return order.id;
                                } catch (parseError) {
                                    debugLog('JSON parse error', parseError.message);
                                    throw new Error('Invalid response from server: ' + text.substring(0,
                                        200));
                                }
                            })
                            .catch(err => {
                                debugLog('Create order error', err.message);
                                console.error('Full error details:', err);
                                alert('Error creating order: ' + err.message);
                                throw err;
                            });
                    },

                    onApprove: function(data, actions) {
                        debugLog('Payment approved, capturing order', data.orderID);

                        return fetch('simple_capture_order.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify({
                                    orderID: data.orderID
                                })
                            })
                            .then(response => {
                                debugLog('Capture response status', response.status);

                                if (!response.ok) {
                                    throw new Error(`HTTP error! status: ${response.status}`);
                                }

                                return response.text();
                            })
                            .then(text => {
                                debugLog('Capture raw response', text);

                                try {
                                    const details = JSON.parse(text);
                                    debugLog('Capture parsed response', details);

                                    if (details.error) {
                                        throw new Error(details.error + (details.message ? ': ' + details
                                            .message : ''));
                                    }

                                    debugLog('Payment completed successfully');

                                    alert('Payment successful! Order ID: ' + details.order_id);
                                    window.location.href = 'simple_success.php?order=' + details.order_id;
                                } catch (parseError) {
                                    debugLog('Capture JSON parse error', parseError.message);
                                    throw new Error('Invalid response during payment capture: ' + text
                                        .substring(0, 200));
                                }
                            })
                            .catch(err => {
                                debugLog('Capture payment error', err.message);
                                console.error('Full capture error:', err);
                                alert('Error processing payment: ' + err.message);
                            });
                    },

                    onError: function(err) {
                        debugLog('PayPal button error', err);
                        console.error('PayPal error details:', err);
                        alert('PayPal error occurred. Please check the console for details and try again.');
                    },

                    onCancel: function(data) {
                        debugLog('Payment cancelled', data);
                        alert('Payment was cancelled.');
                    }
                }).render('#paypal-button-container')
                .then(() => {
                    debugLog('PayPal button rendered successfully');
                })
                .catch(err => {
                    debugLog('PayPal button render error', err.message);
                    console.error('Render error:', err);
                    alert('Failed to load PayPal button: ' + err.message);
                });

        <?php endif; ?>
    });
</script>

<style>
    .card {
        border: 1px solid #dee2e6;
        border-radius: 8px;
    }

    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
        font-weight: 500;
    }

    #paypal-button-container {
        margin: 1rem 0;
    }

    .text-primary {
        color: #007bff !important;
    }

    address {
        margin-bottom: 0;
        line-height: 1.5;
    }

    #debug-info {
        background: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        padding: 10px;
        max-height: 200px;
        overflow-y: auto;
        font-family: monospace;
        font-size: 11px;
    }
</style>

<?php include '../includes/layouts/footer.php'; ?>