<?php
define('PAYPAL_ORDER_PROCESSING', true);

ob_start();
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

require_once '../includes/bootstrap.php';
require_once '../includes/cart.php';
require_once '../includes/paypal_config.php';
require_once '../vendor/autoload.php';

try {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['user_id'])) {
        throw new Exception('User not authenticated');
    }

    if (!validatePayPalConfig()) {
        throw new Exception('PayPal configuration is incomplete');
    }

    $credentials = getPayPalCredentials();
    error_log("PayPal Create Order - Environment: " . PAYPAL_ENVIRONMENT);
    error_log("PayPal Create Order - Starting order creation for user: " . $_SESSION['user_id']);

    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!$data) {
        throw new Exception('Invalid JSON data received');
    }

    $total = floatval($data['total'] ?? 0);
    $address_id = intval($data['address_id'] ?? 0);

    if ($total <= 0) {
        throw new Exception('Invalid order total');
    }

    if ($address_id <= 0) {
        throw new Exception('Invalid address ID');
    }

    $stmt = $conn->prepare("SELECT * FROM addresses WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $address_id, $_SESSION['user_id']);
    $stmt->execute();
    $shipping_address = $stmt->get_result()->fetch_assoc();

    if (!$shipping_address) {
        throw new Exception('Shipping address not found');
    }

    $cart_data = getCartItems();
    $cart_items = $cart_data['items'];

    if (empty($cart_items)) {
        throw new Exception('Cart is empty');
    }

    $subtotal = 0;
    $order_items = [];

    foreach ($cart_items as $item) {
        $item_total = $item['price'] * $item['quantity'];
        $subtotal += $item_total;

        $order_items[] = [
            'name' => substr($item['name'], 0, 100),
            'description' => 'Digital product',
            'unit_amount' => [
                'currency_code' => 'USD',
                'value' => number_format($item['price'], 2, '.', '')
            ],
            'quantity' => (string)$item['quantity'],
            'category' => 'DIGITAL_GOODS'
        ];
    }

    $tax_amount = round($subtotal * 0.10, 2);
    $total_formatted = number_format($subtotal + $tax_amount, 2, '.', '');

    if (PAYPAL_ENVIRONMENT === 'sandbox') {
        $environment = new \PayPalCheckoutSdk\Core\SandboxEnvironment($credentials['client_id'], $credentials['client_secret']);
    } else {
        $environment = new \PayPalCheckoutSdk\Core\ProductionEnvironment($credentials['client_id'], $credentials['client_secret']);
    }

    $client = new \PayPalCheckoutSdk\Core\PayPalHttpClient($environment);

    $request = new \PayPalCheckoutSdk\Orders\OrdersCreateRequest();
    $request->prefer('return=representation');

    $request->body = [
        'intent' => 'CAPTURE',
        'application_context' => [
            'return_url' => '/checkout/simple_success.php',
            'cancel_url' => '/checkout/simple_checkout.php',
            'brand_name' => 'Ryvah Commerce',
            'user_action' => 'PAY_NOW'
        ],
        'purchase_units' => [[
            'reference_id' => 'ORDER_' . $_SESSION['user_id'] . '_' . time(),
            'description' => 'Ryvah Commerce Order',
            'amount' => [
                'currency_code' => 'USD',
                'value' => $total_formatted,
                'breakdown' => [
                    'item_total' => [
                        'currency_code' => 'USD',
                        'value' => number_format($subtotal, 2, '.', '')
                    ],
                    'tax_total' => [
                        'currency_code' => 'USD',
                        'value' => number_format($tax_amount, 2, '.', '')
                    ]
                ]
            ],
            'items' => $order_items
        ]]
    ];

    $response = $client->execute($request);

    if (!isset($response->result->id)) {
        throw new Exception('PayPal order creation failed - no order ID returned');
    }

    $invoice_number = 'INV-' . date('Ymd') . '-' . $_SESSION['user_id'] . '-' . rand(1000, 9999);
    $shipping_json = json_encode($shipping_address);

    $stmt = $conn->prepare("INSERT INTO orders (invoice_number, user_id, total_amount, tax_amount, payment_status, paypal_order_id, shipping_address) VALUES (?, ?, ?, ?, 'pending', ?, ?)");
    $stmt->bind_param("siddss", $invoice_number, $_SESSION['user_id'], $subtotal + $tax_amount, $tax_amount, $response->result->id, $shipping_json);
    if (!$stmt->execute()) {
        throw new Exception('Database error: ' . $stmt->error);
    }

    $order_id = $conn->insert_id;

    $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)");
    foreach ($cart_items as $item) {
        $item_subtotal = $item['price'] * $item['quantity'];
        $stmt->bind_param("iiidd", $order_id, $item['id'], $item['quantity'], $item['price'], $item_subtotal);
        $stmt->execute();
    }

    ob_clean();
    echo json_encode([
        'id' => $response->result->id,
        'status' => 'success',
        'database_order_id' => $order_id,
        'environment' => PAYPAL_ENVIRONMENT
    ]);
} catch (Exception $e) {
    error_log("PayPal Create Order - Error: " . $e->getMessage());
    error_log("PayPal Create Order - Stack trace: " . $e->getTraceAsString());

    ob_clean();
    http_response_code(500);
    echo json_encode([
        'error' => 'Order creation failed',
        'message' => $e->getMessage(),
        'environment' => PAYPAL_ENVIRONMENT ?? 'unknown'
    ]);
}

ob_end_flush();
